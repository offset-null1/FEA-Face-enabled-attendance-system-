#!/usr/bin/python3
from io import StringIO,BytesIO
from backend.mysqlConnector import MysqlConnector
from flask import Flask, render_template, Response,redirect, url_for,request
from backend.detect_faces import detector
from backend.embedding import kernel
from flask_socketio import SocketIO,emit
from flask_cors import CORS,cross_origin
from PIL import Image
import base64
import logging
import cv2
import sys
import os

fileName = sys.argv[0]

cwd = os.getcwd()

if fileName.startswith('.'):
    PATH = cwd + fileName[1:]
elif fileName.startswith('/'):
    PATH = fileName
else:
    PATH = cwd + '/' + fileName

logging.info(f' PATH to executable {PATH}')

for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)


logging.basicConfig(
    filename=PATH +'-application.log',
    format='%(asctime)s.%(msecs)-3d:%(filename)s:%(funcName)s:%(levelname)s:%(lineno)d:%(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    level=logging.DEBUG
)

conn = MysqlConnector()


app = Flask(__name__)
cors = CORS(app)
app.config['SECRET_KEY']='blaaaaahblahblahbalhhh'
socket = SocketIO(app,cors_allowed_origin="*")


@app.route('/')
def base():
    return render_template('navbar.html')

def gen(detector_obj):
    network = kernel.load_model()
    while True:
        raw_detect,roi = detector_obj.detect()
        yield (b'--frame\r\n'
                 b'Content-Type: image/jpeg\r\n\r\n' + raw_detect + b'\r\n')
   
@app.route('/video')
def video():
    return Response(gen(detector()), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/attendance/')
def attendance():
    return render_template("video_feed.html")


@app.route('/live_train',methods=['GET','POST'])
@cross_origin()
def live_train():
    print("Live train")
    return render_template('del.html')
    
@app.route('/form', methods=["POST","GET"])
def form():

    if request.method == 'POST':
        usn = request.form.get('usn')
        fname = request.form.get('fname')
        lname= request.form.get('lname')
        email = request.form.get('email')
        phone_no = request.form.get('phone_no')
        semester = int(request.form.get('semester'))
        conn.insert(tableName='teacher',values=(usn,fname,lname,email,phone_no,'Null',semester))
        res=conn.select(columnName="*",tableName='students')
        conn.commit()
        print("\nData received. Now redirecting ...")
        
        return redirect(url_for('live_train'))
    else:   
        return render_template("user/form.html")
    

@socket.on('connect')
def connect():
    print("Got a request from",request.remote_addr)
    socket.emit('connect response')
    
@socket.on('image')
def image(data):
    sbuf = StringIO()
    sbuf.write(data)
    sbuf.peek(0)
    print(sbuf.read())
    byte= BytesIO(base64.b64decode(data))
    # frame = Image.open(byte)
    image = cv2.imread(byte)
    cv2.imshow('received',image)
    
@socket.on('disconnect')
def disconnect():
    print('DISCONNECTED, Bye!')
# @app.route('/<string:page>/')
# def show(page):
#     return render_template(url_for(page))

if __name__ == '__main__':
    # app.run(debug=True)
    socket.run(app,host='0.0.0.0')

